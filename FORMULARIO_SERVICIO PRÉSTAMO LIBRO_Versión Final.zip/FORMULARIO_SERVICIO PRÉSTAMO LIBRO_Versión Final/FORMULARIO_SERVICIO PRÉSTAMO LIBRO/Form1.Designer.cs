﻿namespace FORMULARIO_SERVICIO_PRÉSTAMO_LIBRO
{
    partial class FrmBiblioteca
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmBiblioteca));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.LblCodigoEstudiante = new System.Windows.Forms.Label();
            this.GpbEstudiantes = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.CmbEstadoMatricula = new System.Windows.Forms.ComboBox();
            this.LblEstadoMatricula = new System.Windows.Forms.Label();
            this.TxtApellidosEstudiante = new System.Windows.Forms.TextBox();
            this.LblApellidosEstudiante = new System.Windows.Forms.Label();
            this.TxtNombresEstudiante = new System.Windows.Forms.TextBox();
            this.LblNombreEstudiante = new System.Windows.Forms.Label();
            this.TxtCodigoEstudiante = new System.Windows.Forms.TextBox();
            this.GpbGestionPrestamo = new System.Windows.Forms.GroupBox();
            this.TxtCodigoULPrestamo = new System.Windows.Forms.TextBox();
            this.LblCodigoEstPrestamo = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.TxtCodigoEstPrestamo = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.LblCodigoULPrestamo = new System.Windows.Forms.Label();
            this.GpbDevoluciones = new System.Windows.Forms.GroupBox();
            this.TxtCodigoULDevolucion = new System.Windows.Forms.TextBox();
            this.LblCodigoULDevolucion = new System.Windows.Forms.Label();
            this.TabContenido = new System.Windows.Forms.TabControl();
            this.TabBienvenida = new System.Windows.Forms.TabPage();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.LblBienvenidos = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.LblTituloSistema_1 = new System.Windows.Forms.Label();
            this.LblTituloSistema_2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.TabEstudiantes = new System.Windows.Forms.TabPage();
            this.btnCargarTxTEstudiantes = new System.Windows.Forms.Button();
            this.btnModificarEstudiante = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.GpbRegistroEstudiantes = new System.Windows.Forms.GroupBox();
            this.DgvEstudiantes = new System.Windows.Forms.DataGridView();
            this.ColCodigoEst = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColNombresEst = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColApellidosEst = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColEstadoMatriculaEst = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnSeleccionEstudiante = new System.Windows.Forms.Button();
            this.BtnBurbujaEstudiante = new System.Windows.Forms.Button();
            this.BtnEliminar = new System.Windows.Forms.Button();
            this.BtnBuscar = new System.Windows.Forms.Button();
            this.BtnMostrarEstudiante = new System.Windows.Forms.Button();
            this.BtnRegistrarEstudiante = new System.Windows.Forms.Button();
            this.TabLibros = new System.Windows.Forms.TabPage();
            this.btnCargarTxTLibros = new System.Windows.Forms.Button();
            this.btnModificarLibro = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.GpbRegistrosLibro = new System.Windows.Forms.GroupBox();
            this.DgvLibros = new System.Windows.Forms.DataGridView();
            this.ColCodigoLibro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColTituloLibro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColAreaLibro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColCodULLibro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel7 = new System.Windows.Forms.Panel();
            this.GpbDatosLibro = new System.Windows.Forms.GroupBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.TxtAreaLibro = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.TxtTituloLibro = new System.Windows.Forms.TextBox();
            this.LblAreaLibro = new System.Windows.Forms.Label();
            this.LblTituloLibro = new System.Windows.Forms.Label();
            this.BtnSeleccionLibro = new System.Windows.Forms.Button();
            this.BtnBurbujaLibro = new System.Windows.Forms.Button();
            this.BtnEliminarLibro = new System.Windows.Forms.Button();
            this.BtnBuscarLibro = new System.Windows.Forms.Button();
            this.BtnMostrarLibro = new System.Windows.Forms.Button();
            this.BtnRegistrarLibro = new System.Windows.Forms.Button();
            this.TabPrestamos = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.GpbRegistrosPrestamo = new System.Windows.Forms.GroupBox();
            this.DgvPrestamos = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColCodULLibroP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColFechaPrestamo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColFechaDevolucion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColEstado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel11 = new System.Windows.Forms.Panel();
            this.BtnBuscarPrestamo = new System.Windows.Forms.Button();
            this.BtnMostrarPrestamo = new System.Windows.Forms.Button();
            this.BtnRegistrarPrestamo = new System.Windows.Forms.Button();
            this.TabDevoluciones = new System.Windows.Forms.TabPage();
            this.panel14 = new System.Windows.Forms.Panel();
            this.GpbRegistroDevoluciones = new System.Windows.Forms.GroupBox();
            this.TxtDevolucion = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.BtnRegistrarDevolucion = new System.Windows.Forms.Button();
            this.BtnHistorialDevoluciones = new System.Windows.Forms.Button();
            this.BtnLibros = new System.Windows.Forms.Button();
            this.BtnPrestamo = new System.Windows.Forms.Button();
            this.BtnDevoluciones = new System.Windows.Forms.Button();
            this.PnlBotones = new System.Windows.Forms.Panel();
            this.BtnEstudiantes = new System.Windows.Forms.Button();
            this.PnlLogo = new System.Windows.Forms.Panel();
            this.PicLogo = new System.Windows.Forms.PictureBox();
            this.GpbEstudiantes.SuspendLayout();
            this.GpbGestionPrestamo.SuspendLayout();
            this.GpbDevoluciones.SuspendLayout();
            this.TabContenido.SuspendLayout();
            this.TabBienvenida.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.TabEstudiantes.SuspendLayout();
            this.panel5.SuspendLayout();
            this.GpbRegistroEstudiantes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvEstudiantes)).BeginInit();
            this.panel1.SuspendLayout();
            this.TabLibros.SuspendLayout();
            this.panel8.SuspendLayout();
            this.GpbRegistrosLibro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvLibros)).BeginInit();
            this.panel7.SuspendLayout();
            this.GpbDatosLibro.SuspendLayout();
            this.TabPrestamos.SuspendLayout();
            this.panel12.SuspendLayout();
            this.GpbRegistrosPrestamo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DgvPrestamos)).BeginInit();
            this.panel11.SuspendLayout();
            this.TabDevoluciones.SuspendLayout();
            this.panel14.SuspendLayout();
            this.GpbRegistroDevoluciones.SuspendLayout();
            this.panel13.SuspendLayout();
            this.PnlBotones.SuspendLayout();
            this.PnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PicLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // LblCodigoEstudiante
            // 
            this.LblCodigoEstudiante.AutoSize = true;
            this.LblCodigoEstudiante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.LblCodigoEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCodigoEstudiante.Location = new System.Drawing.Point(29, 29);
            this.LblCodigoEstudiante.Name = "LblCodigoEstudiante";
            this.LblCodigoEstudiante.Size = new System.Drawing.Size(137, 17);
            this.LblCodigoEstudiante.TabIndex = 4;
            this.LblCodigoEstudiante.Text = "Código de Estudiante:";
            // 
            // GpbEstudiantes
            // 
            this.GpbEstudiantes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbEstudiantes.Controls.Add(this.panel6);
            this.GpbEstudiantes.Controls.Add(this.panel4);
            this.GpbEstudiantes.Controls.Add(this.panel3);
            this.GpbEstudiantes.Controls.Add(this.panel2);
            this.GpbEstudiantes.Controls.Add(this.CmbEstadoMatricula);
            this.GpbEstudiantes.Controls.Add(this.LblEstadoMatricula);
            this.GpbEstudiantes.Controls.Add(this.TxtApellidosEstudiante);
            this.GpbEstudiantes.Controls.Add(this.LblApellidosEstudiante);
            this.GpbEstudiantes.Controls.Add(this.TxtNombresEstudiante);
            this.GpbEstudiantes.Controls.Add(this.LblNombreEstudiante);
            this.GpbEstudiantes.Controls.Add(this.TxtCodigoEstudiante);
            this.GpbEstudiantes.Controls.Add(this.LblCodigoEstudiante);
            this.GpbEstudiantes.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbEstudiantes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbEstudiantes.Location = new System.Drawing.Point(7, 3);
            this.GpbEstudiantes.Name = "GpbEstudiantes";
            this.GpbEstudiantes.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.GpbEstudiantes.Size = new System.Drawing.Size(689, 180);
            this.GpbEstudiantes.TabIndex = 5;
            this.GpbEstudiantes.TabStop = false;
            this.GpbEstudiantes.Text = "Datos del Estudiante";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel6.Location = new System.Drawing.Point(22, 105);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(5, 15);
            this.panel6.TabIndex = 20;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel4.Location = new System.Drawing.Point(22, 150);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 15);
            this.panel4.TabIndex = 18;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel3.Location = new System.Drawing.Point(22, 69);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 15);
            this.panel3.TabIndex = 18;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel2.Location = new System.Drawing.Point(22, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(5, 15);
            this.panel2.TabIndex = 18;
            // 
            // CmbEstadoMatricula
            // 
            this.CmbEstadoMatricula.BackColor = System.Drawing.Color.White;
            this.CmbEstadoMatricula.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbEstadoMatricula.FormattingEnabled = true;
            this.CmbEstadoMatricula.Items.AddRange(new object[] {
            "ACTIVO",
            "INACTIVO"});
            this.CmbEstadoMatricula.Location = new System.Drawing.Point(183, 145);
            this.CmbEstadoMatricula.Name = "CmbEstadoMatricula";
            this.CmbEstadoMatricula.Size = new System.Drawing.Size(493, 25);
            this.CmbEstadoMatricula.TabIndex = 10;
            // 
            // LblEstadoMatricula
            // 
            this.LblEstadoMatricula.AutoSize = true;
            this.LblEstadoMatricula.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.LblEstadoMatricula.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblEstadoMatricula.Location = new System.Drawing.Point(29, 148);
            this.LblEstadoMatricula.Name = "LblEstadoMatricula";
            this.LblEstadoMatricula.Size = new System.Drawing.Size(128, 17);
            this.LblEstadoMatricula.TabIndex = 9;
            this.LblEstadoMatricula.Text = "Estado de Matrícula:";
            // 
            // TxtApellidosEstudiante
            // 
            this.TxtApellidosEstudiante.BackColor = System.Drawing.Color.White;
            this.TxtApellidosEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtApellidosEstudiante.Location = new System.Drawing.Point(183, 101);
            this.TxtApellidosEstudiante.Name = "TxtApellidosEstudiante";
            this.TxtApellidosEstudiante.Size = new System.Drawing.Size(493, 25);
            this.TxtApellidosEstudiante.TabIndex = 8;
            // 
            // LblApellidosEstudiante
            // 
            this.LblApellidosEstudiante.AutoSize = true;
            this.LblApellidosEstudiante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.LblApellidosEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblApellidosEstudiante.Location = new System.Drawing.Point(29, 104);
            this.LblApellidosEstudiante.Name = "LblApellidosEstudiante";
            this.LblApellidosEstudiante.Size = new System.Drawing.Size(65, 17);
            this.LblApellidosEstudiante.TabIndex = 7;
            this.LblApellidosEstudiante.Text = "Apellidos:";
            // 
            // TxtNombresEstudiante
            // 
            this.TxtNombresEstudiante.BackColor = System.Drawing.Color.White;
            this.TxtNombresEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtNombresEstudiante.Location = new System.Drawing.Point(183, 64);
            this.TxtNombresEstudiante.Name = "TxtNombresEstudiante";
            this.TxtNombresEstudiante.Size = new System.Drawing.Size(493, 25);
            this.TxtNombresEstudiante.TabIndex = 7;
            // 
            // LblNombreEstudiante
            // 
            this.LblNombreEstudiante.AutoSize = true;
            this.LblNombreEstudiante.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.LblNombreEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNombreEstudiante.Location = new System.Drawing.Point(29, 67);
            this.LblNombreEstudiante.Name = "LblNombreEstudiante";
            this.LblNombreEstudiante.Size = new System.Drawing.Size(66, 17);
            this.LblNombreEstudiante.TabIndex = 6;
            this.LblNombreEstudiante.Text = "Nombres:";
            // 
            // TxtCodigoEstudiante
            // 
            this.TxtCodigoEstudiante.BackColor = System.Drawing.Color.White;
            this.TxtCodigoEstudiante.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCodigoEstudiante.Location = new System.Drawing.Point(183, 26);
            this.TxtCodigoEstudiante.Name = "TxtCodigoEstudiante";
            this.TxtCodigoEstudiante.Size = new System.Drawing.Size(493, 25);
            this.TxtCodigoEstudiante.TabIndex = 6;
            // 
            // GpbGestionPrestamo
            // 
            this.GpbGestionPrestamo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbGestionPrestamo.Controls.Add(this.TxtCodigoULPrestamo);
            this.GpbGestionPrestamo.Controls.Add(this.LblCodigoEstPrestamo);
            this.GpbGestionPrestamo.Controls.Add(this.panel16);
            this.GpbGestionPrestamo.Controls.Add(this.TxtCodigoEstPrestamo);
            this.GpbGestionPrestamo.Controls.Add(this.panel15);
            this.GpbGestionPrestamo.Controls.Add(this.LblCodigoULPrestamo);
            this.GpbGestionPrestamo.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbGestionPrestamo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbGestionPrestamo.Location = new System.Drawing.Point(10, 2);
            this.GpbGestionPrestamo.Name = "GpbGestionPrestamo";
            this.GpbGestionPrestamo.Size = new System.Drawing.Size(684, 122);
            this.GpbGestionPrestamo.TabIndex = 8;
            this.GpbGestionPrestamo.TabStop = false;
            this.GpbGestionPrestamo.Text = "Préstamos";
            // 
            // TxtCodigoULPrestamo
            // 
            this.TxtCodigoULPrestamo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCodigoULPrestamo.Location = new System.Drawing.Point(180, 82);
            this.TxtCodigoULPrestamo.Name = "TxtCodigoULPrestamo";
            this.TxtCodigoULPrestamo.Size = new System.Drawing.Size(491, 25);
            this.TxtCodigoULPrestamo.TabIndex = 12;
            // 
            // LblCodigoEstPrestamo
            // 
            this.LblCodigoEstPrestamo.AutoSize = true;
            this.LblCodigoEstPrestamo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCodigoEstPrestamo.Location = new System.Drawing.Point(26, 39);
            this.LblCodigoEstPrestamo.Name = "LblCodigoEstPrestamo";
            this.LblCodigoEstPrestamo.Size = new System.Drawing.Size(140, 17);
            this.LblCodigoEstPrestamo.TabIndex = 9;
            this.LblCodigoEstPrestamo.Text = "Código del estudiante:";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel16.Location = new System.Drawing.Point(15, 86);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(5, 15);
            this.panel16.TabIndex = 19;
            // 
            // TxtCodigoEstPrestamo
            // 
            this.TxtCodigoEstPrestamo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCodigoEstPrestamo.Location = new System.Drawing.Point(180, 36);
            this.TxtCodigoEstPrestamo.Name = "TxtCodigoEstPrestamo";
            this.TxtCodigoEstPrestamo.Size = new System.Drawing.Size(491, 25);
            this.TxtCodigoEstPrestamo.TabIndex = 11;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel15.Location = new System.Drawing.Point(15, 41);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(5, 15);
            this.panel15.TabIndex = 18;
            // 
            // LblCodigoULPrestamo
            // 
            this.LblCodigoULPrestamo.AutoSize = true;
            this.LblCodigoULPrestamo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCodigoULPrestamo.Location = new System.Drawing.Point(24, 85);
            this.LblCodigoULPrestamo.Name = "LblCodigoULPrestamo";
            this.LblCodigoULPrestamo.Size = new System.Drawing.Size(150, 17);
            this.LblCodigoULPrestamo.TabIndex = 10;
            this.LblCodigoULPrestamo.Text = "Código UL del ejemplar:";
            // 
            // GpbDevoluciones
            // 
            this.GpbDevoluciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbDevoluciones.Controls.Add(this.TxtCodigoULDevolucion);
            this.GpbDevoluciones.Controls.Add(this.LblCodigoULDevolucion);
            this.GpbDevoluciones.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbDevoluciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbDevoluciones.Location = new System.Drawing.Point(11, 3);
            this.GpbDevoluciones.Name = "GpbDevoluciones";
            this.GpbDevoluciones.Size = new System.Drawing.Size(667, 84);
            this.GpbDevoluciones.TabIndex = 9;
            this.GpbDevoluciones.TabStop = false;
            this.GpbDevoluciones.Text = "Devoluciones";
            // 
            // TxtCodigoULDevolucion
            // 
            this.TxtCodigoULDevolucion.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtCodigoULDevolucion.Location = new System.Drawing.Point(183, 41);
            this.TxtCodigoULDevolucion.Name = "TxtCodigoULDevolucion";
            this.TxtCodigoULDevolucion.Size = new System.Drawing.Size(467, 25);
            this.TxtCodigoULDevolucion.TabIndex = 1;
            // 
            // LblCodigoULDevolucion
            // 
            this.LblCodigoULDevolucion.AutoSize = true;
            this.LblCodigoULDevolucion.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblCodigoULDevolucion.Location = new System.Drawing.Point(27, 44);
            this.LblCodigoULDevolucion.Name = "LblCodigoULDevolucion";
            this.LblCodigoULDevolucion.Size = new System.Drawing.Size(150, 17);
            this.LblCodigoULDevolucion.TabIndex = 0;
            this.LblCodigoULDevolucion.Text = "Código UL del ejemplar:";
            // 
            // TabContenido
            // 
            this.TabContenido.Controls.Add(this.TabBienvenida);
            this.TabContenido.Controls.Add(this.TabEstudiantes);
            this.TabContenido.Controls.Add(this.TabLibros);
            this.TabContenido.Controls.Add(this.TabPrestamos);
            this.TabContenido.Controls.Add(this.TabDevoluciones);
            this.TabContenido.Location = new System.Drawing.Point(125, -8);
            this.TabContenido.Name = "TabContenido";
            this.TabContenido.SelectedIndex = 0;
            this.TabContenido.Size = new System.Drawing.Size(741, 544);
            this.TabContenido.TabIndex = 10;
            // 
            // TabBienvenida
            // 
            this.TabBienvenida.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(243)))), ((int)(((byte)(215)))));
            this.TabBienvenida.Controls.Add(this.pictureBox2);
            this.TabBienvenida.Controls.Add(this.LblBienvenidos);
            this.TabBienvenida.Controls.Add(this.pictureBox4);
            this.TabBienvenida.Controls.Add(this.panel21);
            this.TabBienvenida.Controls.Add(this.panel18);
            this.TabBienvenida.Controls.Add(this.LblTituloSistema_1);
            this.TabBienvenida.Controls.Add(this.LblTituloSistema_2);
            this.TabBienvenida.Controls.Add(this.pictureBox1);
            this.TabBienvenida.Controls.Add(this.pictureBox3);
            this.TabBienvenida.Location = new System.Drawing.Point(4, 22);
            this.TabBienvenida.Name = "TabBienvenida";
            this.TabBienvenida.Size = new System.Drawing.Size(733, 518);
            this.TabBienvenida.TabIndex = 4;
            this.TabBienvenida.Text = "Bienvenida";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(179, 259);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(237, 225);
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // LblBienvenidos
            // 
            this.LblBienvenidos.AutoSize = true;
            this.LblBienvenidos.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBienvenidos.Location = new System.Drawing.Point(140, 29);
            this.LblBienvenidos.Name = "LblBienvenidos";
            this.LblBienvenidos.Size = new System.Drawing.Size(439, 74);
            this.LblBienvenidos.TabIndex = 12;
            this.LblBienvenidos.Text = "¡Bienvenido!";
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(556, 16);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(55, 65);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel21.Location = new System.Drawing.Point(78, 216);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(551, 6);
            this.panel21.TabIndex = 14;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel18.Location = new System.Drawing.Point(78, 111);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(551, 6);
            this.panel18.TabIndex = 13;
            // 
            // LblTituloSistema_1
            // 
            this.LblTituloSistema_1.AutoSize = true;
            this.LblTituloSistema_1.Font = new System.Drawing.Font("Sylfaen", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTituloSistema_1.ForeColor = System.Drawing.Color.Black;
            this.LblTituloSistema_1.Location = new System.Drawing.Point(151, 130);
            this.LblTituloSistema_1.Name = "LblTituloSistema_1";
            this.LblTituloSistema_1.Size = new System.Drawing.Size(397, 35);
            this.LblTituloSistema_1.TabIndex = 10;
            this.LblTituloSistema_1.Text = "Sistema de Préstamos de Libros";
            // 
            // LblTituloSistema_2
            // 
            this.LblTituloSistema_2.AutoSize = true;
            this.LblTituloSistema_2.Font = new System.Drawing.Font("Sylfaen", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTituloSistema_2.ForeColor = System.Drawing.Color.Black;
            this.LblTituloSistema_2.Location = new System.Drawing.Point(251, 169);
            this.LblTituloSistema_2.Name = "LblTituloSistema_2";
            this.LblTituloSistema_2.Size = new System.Drawing.Size(204, 35);
            this.LblTituloSistema_2.TabIndex = 11;
            this.LblTituloSistema_2.Text = "de la Biblioteca";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 246);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(734, 279);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(107, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(55, 65);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 16;
            this.pictureBox3.TabStop = false;
            // 
            // TabEstudiantes
            // 
            this.TabEstudiantes.BackColor = System.Drawing.Color.White;
            this.TabEstudiantes.Controls.Add(this.btnCargarTxTEstudiantes);
            this.TabEstudiantes.Controls.Add(this.btnModificarEstudiante);
            this.TabEstudiantes.Controls.Add(this.panel5);
            this.TabEstudiantes.Controls.Add(this.panel1);
            this.TabEstudiantes.Controls.Add(this.BtnSeleccionEstudiante);
            this.TabEstudiantes.Controls.Add(this.BtnBurbujaEstudiante);
            this.TabEstudiantes.Controls.Add(this.BtnEliminar);
            this.TabEstudiantes.Controls.Add(this.BtnBuscar);
            this.TabEstudiantes.Controls.Add(this.BtnMostrarEstudiante);
            this.TabEstudiantes.Controls.Add(this.BtnRegistrarEstudiante);
            this.TabEstudiantes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.TabEstudiantes.Location = new System.Drawing.Point(4, 22);
            this.TabEstudiantes.Name = "TabEstudiantes";
            this.TabEstudiantes.Padding = new System.Windows.Forms.Padding(3);
            this.TabEstudiantes.Size = new System.Drawing.Size(733, 518);
            this.TabEstudiantes.TabIndex = 0;
            this.TabEstudiantes.Text = "Estudiantes";
            // 
            // btnCargarTxTEstudiantes
            // 
            this.btnCargarTxTEstudiantes.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.btnCargarTxTEstudiantes.FlatAppearance.BorderSize = 2;
            this.btnCargarTxTEstudiantes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCargarTxTEstudiantes.Location = new System.Drawing.Point(233, 280);
            this.btnCargarTxTEstudiantes.Name = "btnCargarTxTEstudiantes";
            this.btnCargarTxTEstudiantes.Size = new System.Drawing.Size(117, 37);
            this.btnCargarTxTEstudiantes.TabIndex = 21;
            this.btnCargarTxTEstudiantes.Text = "Cargar TxT";
            this.btnCargarTxTEstudiantes.UseVisualStyleBackColor = true;
            this.btnCargarTxTEstudiantes.Click += new System.EventHandler(this.btnCargarTxTEstudiantes_Click);
            // 
            // btnModificarEstudiante
            // 
            this.btnModificarEstudiante.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.btnModificarEstudiante.FlatAppearance.BorderSize = 2;
            this.btnModificarEstudiante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificarEstudiante.Location = new System.Drawing.Point(82, 280);
            this.btnModificarEstudiante.Name = "btnModificarEstudiante";
            this.btnModificarEstudiante.Size = new System.Drawing.Size(117, 37);
            this.btnModificarEstudiante.TabIndex = 20;
            this.btnModificarEstudiante.Text = "Modificar";
            this.btnModificarEstudiante.UseVisualStyleBackColor = true;
            this.btnModificarEstudiante.Click += new System.EventHandler(this.btnModificarEstudiante_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel5.Controls.Add(this.GpbRegistroEstudiantes);
            this.panel5.Location = new System.Drawing.Point(19, 342);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(710, 156);
            this.panel5.TabIndex = 19;
            // 
            // GpbRegistroEstudiantes
            // 
            this.GpbRegistroEstudiantes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbRegistroEstudiantes.Controls.Add(this.DgvEstudiantes);
            this.GpbRegistroEstudiantes.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbRegistroEstudiantes.Location = new System.Drawing.Point(7, 3);
            this.GpbRegistroEstudiantes.Name = "GpbRegistroEstudiantes";
            this.GpbRegistroEstudiantes.Size = new System.Drawing.Size(695, 150);
            this.GpbRegistroEstudiantes.TabIndex = 6;
            this.GpbRegistroEstudiantes.TabStop = false;
            this.GpbRegistroEstudiantes.Text = "Registros de Estudiantes";
            // 
            // DgvEstudiantes
            // 
            this.DgvEstudiantes.AllowUserToAddRows = false;
            this.DgvEstudiantes.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(243)))), ((int)(((byte)(246)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(235)))), ((int)(((byte)(170)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.DgvEstudiantes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DgvEstudiantes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvEstudiantes.BackgroundColor = System.Drawing.Color.White;
            this.DgvEstudiantes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvEstudiantes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DgvEstudiantes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DgvEstudiantes.ColumnHeadersHeight = 38;
            this.DgvEstudiantes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DgvEstudiantes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColCodigoEst,
            this.ColNombresEst,
            this.ColApellidosEst,
            this.ColEstadoMatriculaEst});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(170)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DgvEstudiantes.DefaultCellStyle = dataGridViewCellStyle3;
            this.DgvEstudiantes.EnableHeadersVisualStyles = false;
            this.DgvEstudiantes.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(228)))), ((int)(((byte)(232)))));
            this.DgvEstudiantes.Location = new System.Drawing.Point(13, 39);
            this.DgvEstudiantes.MultiSelect = false;
            this.DgvEstudiantes.Name = "DgvEstudiantes";
            this.DgvEstudiantes.ReadOnly = true;
            this.DgvEstudiantes.RowHeadersVisible = false;
            this.DgvEstudiantes.RowTemplate.Height = 32;
            this.DgvEstudiantes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvEstudiantes.Size = new System.Drawing.Size(670, 98);
            this.DgvEstudiantes.TabIndex = 0;
            this.DgvEstudiantes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvEstudiantes_CellClick);
            // 
            // ColCodigoEst
            // 
            this.ColCodigoEst.HeaderText = "Código";
            this.ColCodigoEst.Name = "ColCodigoEst";
            this.ColCodigoEst.ReadOnly = true;
            // 
            // ColNombresEst
            // 
            this.ColNombresEst.HeaderText = "Nombres";
            this.ColNombresEst.Name = "ColNombresEst";
            this.ColNombresEst.ReadOnly = true;
            // 
            // ColApellidosEst
            // 
            this.ColApellidosEst.HeaderText = "Apellidos";
            this.ColApellidosEst.Name = "ColApellidosEst";
            this.ColApellidosEst.ReadOnly = true;
            // 
            // ColEstadoMatriculaEst
            // 
            this.ColEstadoMatriculaEst.HeaderText = "Estado de Matrícula";
            this.ColEstadoMatriculaEst.Name = "ColEstadoMatriculaEst";
            this.ColEstadoMatriculaEst.ReadOnly = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel1.Controls.Add(this.GpbEstudiantes);
            this.panel1.Location = new System.Drawing.Point(20, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(703, 185);
            this.panel1.TabIndex = 13;
            // 
            // BtnSeleccionEstudiante
            // 
            this.BtnSeleccionEstudiante.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnSeleccionEstudiante.FlatAppearance.BorderSize = 2;
            this.BtnSeleccionEstudiante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSeleccionEstudiante.Location = new System.Drawing.Point(535, 280);
            this.BtnSeleccionEstudiante.Name = "BtnSeleccionEstudiante";
            this.BtnSeleccionEstudiante.Size = new System.Drawing.Size(117, 37);
            this.BtnSeleccionEstudiante.TabIndex = 12;
            this.BtnSeleccionEstudiante.Text = "Ordenar (Selección)";
            this.BtnSeleccionEstudiante.UseVisualStyleBackColor = true;
            this.BtnSeleccionEstudiante.Click += new System.EventHandler(this.BtnSeleccionEstudiante_Click);
            // 
            // BtnBurbujaEstudiante
            // 
            this.BtnBurbujaEstudiante.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnBurbujaEstudiante.FlatAppearance.BorderSize = 2;
            this.BtnBurbujaEstudiante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBurbujaEstudiante.Location = new System.Drawing.Point(384, 280);
            this.BtnBurbujaEstudiante.Name = "BtnBurbujaEstudiante";
            this.BtnBurbujaEstudiante.Size = new System.Drawing.Size(117, 37);
            this.BtnBurbujaEstudiante.TabIndex = 11;
            this.BtnBurbujaEstudiante.Text = "Ordenar (Burbuja)";
            this.BtnBurbujaEstudiante.UseVisualStyleBackColor = true;
            this.BtnBurbujaEstudiante.Click += new System.EventHandler(this.BtnBurbujaEstudiante_Click);
            // 
            // BtnEliminar
            // 
            this.BtnEliminar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnEliminar.FlatAppearance.BorderSize = 2;
            this.BtnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEliminar.Location = new System.Drawing.Point(535, 234);
            this.BtnEliminar.Name = "BtnEliminar";
            this.BtnEliminar.Size = new System.Drawing.Size(117, 37);
            this.BtnEliminar.TabIndex = 10;
            this.BtnEliminar.Text = "Eliminar";
            this.BtnEliminar.UseVisualStyleBackColor = true;
            this.BtnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // BtnBuscar
            // 
            this.BtnBuscar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnBuscar.FlatAppearance.BorderSize = 2;
            this.BtnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBuscar.Location = new System.Drawing.Point(384, 234);
            this.BtnBuscar.Name = "BtnBuscar";
            this.BtnBuscar.Size = new System.Drawing.Size(117, 37);
            this.BtnBuscar.TabIndex = 9;
            this.BtnBuscar.Text = "Buscar";
            this.BtnBuscar.UseVisualStyleBackColor = true;
            this.BtnBuscar.Click += new System.EventHandler(this.BtnBuscar_Click);
            // 
            // BtnMostrarEstudiante
            // 
            this.BtnMostrarEstudiante.BackColor = System.Drawing.Color.White;
            this.BtnMostrarEstudiante.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnMostrarEstudiante.FlatAppearance.BorderSize = 2;
            this.BtnMostrarEstudiante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMostrarEstudiante.Location = new System.Drawing.Point(233, 234);
            this.BtnMostrarEstudiante.Name = "BtnMostrarEstudiante";
            this.BtnMostrarEstudiante.Size = new System.Drawing.Size(117, 37);
            this.BtnMostrarEstudiante.TabIndex = 8;
            this.BtnMostrarEstudiante.Text = "Mostrar";
            this.BtnMostrarEstudiante.UseVisualStyleBackColor = false;
            this.BtnMostrarEstudiante.Click += new System.EventHandler(this.BtnMostrarEstudiante_Click);
            // 
            // BtnRegistrarEstudiante
            // 
            this.BtnRegistrarEstudiante.BackColor = System.Drawing.Color.White;
            this.BtnRegistrarEstudiante.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnRegistrarEstudiante.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRegistrarEstudiante.Location = new System.Drawing.Point(82, 234);
            this.BtnRegistrarEstudiante.Name = "BtnRegistrarEstudiante";
            this.BtnRegistrarEstudiante.Size = new System.Drawing.Size(117, 37);
            this.BtnRegistrarEstudiante.TabIndex = 7;
            this.BtnRegistrarEstudiante.Text = "Registrar";
            this.BtnRegistrarEstudiante.UseVisualStyleBackColor = false;
            this.BtnRegistrarEstudiante.Click += new System.EventHandler(this.BtnRegistrarEstudiante_Click);
            // 
            // TabLibros
            // 
            this.TabLibros.Controls.Add(this.btnCargarTxTLibros);
            this.TabLibros.Controls.Add(this.btnModificarLibro);
            this.TabLibros.Controls.Add(this.panel8);
            this.TabLibros.Controls.Add(this.panel7);
            this.TabLibros.Controls.Add(this.BtnSeleccionLibro);
            this.TabLibros.Controls.Add(this.BtnBurbujaLibro);
            this.TabLibros.Controls.Add(this.BtnEliminarLibro);
            this.TabLibros.Controls.Add(this.BtnBuscarLibro);
            this.TabLibros.Controls.Add(this.BtnMostrarLibro);
            this.TabLibros.Controls.Add(this.BtnRegistrarLibro);
            this.TabLibros.Location = new System.Drawing.Point(4, 22);
            this.TabLibros.Name = "TabLibros";
            this.TabLibros.Padding = new System.Windows.Forms.Padding(3);
            this.TabLibros.Size = new System.Drawing.Size(733, 518);
            this.TabLibros.TabIndex = 1;
            this.TabLibros.Text = "Libros";
            this.TabLibros.UseVisualStyleBackColor = true;
            // 
            // btnCargarTxTLibros
            // 
            this.btnCargarTxTLibros.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.btnCargarTxTLibros.FlatAppearance.BorderSize = 2;
            this.btnCargarTxTLibros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCargarTxTLibros.Location = new System.Drawing.Point(215, 226);
            this.btnCargarTxTLibros.Name = "btnCargarTxTLibros";
            this.btnCargarTxTLibros.Size = new System.Drawing.Size(124, 37);
            this.btnCargarTxTLibros.TabIndex = 22;
            this.btnCargarTxTLibros.Text = "CargarTxT";
            this.btnCargarTxTLibros.UseVisualStyleBackColor = true;
            this.btnCargarTxTLibros.Click += new System.EventHandler(this.btnCargarTxTLibros_Click);
            // 
            // btnModificarLibro
            // 
            this.btnModificarLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.btnModificarLibro.FlatAppearance.BorderSize = 2;
            this.btnModificarLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificarLibro.Location = new System.Drawing.Point(64, 226);
            this.btnModificarLibro.Name = "btnModificarLibro";
            this.btnModificarLibro.Size = new System.Drawing.Size(124, 34);
            this.btnModificarLibro.TabIndex = 19;
            this.btnModificarLibro.Text = "Modificar";
            this.btnModificarLibro.UseVisualStyleBackColor = true;
            this.btnModificarLibro.Click += new System.EventHandler(this.btnModificarLibro_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel8.Controls.Add(this.GpbRegistrosLibro);
            this.panel8.Location = new System.Drawing.Point(17, 280);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(703, 219);
            this.panel8.TabIndex = 18;
            // 
            // GpbRegistrosLibro
            // 
            this.GpbRegistrosLibro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbRegistrosLibro.Controls.Add(this.DgvLibros);
            this.GpbRegistrosLibro.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbRegistrosLibro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbRegistrosLibro.Location = new System.Drawing.Point(9, 4);
            this.GpbRegistrosLibro.Name = "GpbRegistrosLibro";
            this.GpbRegistrosLibro.Size = new System.Drawing.Size(685, 212);
            this.GpbRegistrosLibro.TabIndex = 14;
            this.GpbRegistrosLibro.TabStop = false;
            this.GpbRegistrosLibro.Text = "Registros de Libros";
            // 
            // DgvLibros
            // 
            this.DgvLibros.AllowUserToAddRows = false;
            this.DgvLibros.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvLibros.BackgroundColor = System.Drawing.Color.White;
            this.DgvLibros.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvLibros.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DgvLibros.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DgvLibros.ColumnHeadersHeight = 38;
            this.DgvLibros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DgvLibros.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColCodigoLibro,
            this.ColTituloLibro,
            this.ColAreaLibro,
            this.ColCodULLibro});
            this.DgvLibros.EnableHeadersVisualStyles = false;
            this.DgvLibros.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(228)))), ((int)(((byte)(232)))));
            this.DgvLibros.Location = new System.Drawing.Point(27, 37);
            this.DgvLibros.MultiSelect = false;
            this.DgvLibros.Name = "DgvLibros";
            this.DgvLibros.ReadOnly = true;
            this.DgvLibros.RowHeadersVisible = false;
            this.DgvLibros.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DgvLibros.Size = new System.Drawing.Size(642, 154);
            this.DgvLibros.TabIndex = 0;
            this.DgvLibros.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvLibros_CellClick);
            // 
            // ColCodigoLibro
            // 
            this.ColCodigoLibro.HeaderText = "Código";
            this.ColCodigoLibro.Name = "ColCodigoLibro";
            this.ColCodigoLibro.ReadOnly = true;
            // 
            // ColTituloLibro
            // 
            this.ColTituloLibro.HeaderText = "Título";
            this.ColTituloLibro.Name = "ColTituloLibro";
            this.ColTituloLibro.ReadOnly = true;
            // 
            // ColAreaLibro
            // 
            this.ColAreaLibro.HeaderText = "Área";
            this.ColAreaLibro.Name = "ColAreaLibro";
            this.ColAreaLibro.ReadOnly = true;
            // 
            // ColCodULLibro
            // 
            this.ColCodULLibro.HeaderText = "Código UL";
            this.ColCodULLibro.Name = "ColCodULLibro";
            this.ColCodULLibro.ReadOnly = true;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel7.Controls.Add(this.GpbDatosLibro);
            this.panel7.Location = new System.Drawing.Point(19, 15);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(699, 132);
            this.panel7.TabIndex = 18;
            // 
            // GpbDatosLibro
            // 
            this.GpbDatosLibro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbDatosLibro.Controls.Add(this.panel10);
            this.GpbDatosLibro.Controls.Add(this.TxtAreaLibro);
            this.GpbDatosLibro.Controls.Add(this.panel9);
            this.GpbDatosLibro.Controls.Add(this.TxtTituloLibro);
            this.GpbDatosLibro.Controls.Add(this.LblAreaLibro);
            this.GpbDatosLibro.Controls.Add(this.LblTituloLibro);
            this.GpbDatosLibro.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbDatosLibro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbDatosLibro.Location = new System.Drawing.Point(7, 4);
            this.GpbDatosLibro.Name = "GpbDatosLibro";
            this.GpbDatosLibro.Size = new System.Drawing.Size(685, 125);
            this.GpbDatosLibro.TabIndex = 7;
            this.GpbDatosLibro.TabStop = false;
            this.GpbDatosLibro.Text = "Datos del Libro";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel10.Location = new System.Drawing.Point(13, 83);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(5, 15);
            this.panel10.TabIndex = 19;
            // 
            // TxtAreaLibro
            // 
            this.TxtAreaLibro.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAreaLibro.Location = new System.Drawing.Point(178, 79);
            this.TxtAreaLibro.Name = "TxtAreaLibro";
            this.TxtAreaLibro.Size = new System.Drawing.Size(491, 25);
            this.TxtAreaLibro.TabIndex = 4;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel9.Location = new System.Drawing.Point(13, 45);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(5, 15);
            this.panel9.TabIndex = 18;
            // 
            // TxtTituloLibro
            // 
            this.TxtTituloLibro.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtTituloLibro.Location = new System.Drawing.Point(178, 40);
            this.TxtTituloLibro.Name = "TxtTituloLibro";
            this.TxtTituloLibro.Size = new System.Drawing.Size(491, 25);
            this.TxtTituloLibro.TabIndex = 3;
            // 
            // LblAreaLibro
            // 
            this.LblAreaLibro.AutoSize = true;
            this.LblAreaLibro.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAreaLibro.Location = new System.Drawing.Point(24, 82);
            this.LblAreaLibro.Name = "LblAreaLibro";
            this.LblAreaLibro.Size = new System.Drawing.Size(121, 17);
            this.LblAreaLibro.TabIndex = 1;
            this.LblAreaLibro.Text = "Área perteneciente:";
            // 
            // LblTituloLibro
            // 
            this.LblTituloLibro.AutoSize = true;
            this.LblTituloLibro.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTituloLibro.Location = new System.Drawing.Point(24, 43);
            this.LblTituloLibro.Name = "LblTituloLibro";
            this.LblTituloLibro.Size = new System.Drawing.Size(99, 17);
            this.LblTituloLibro.TabIndex = 0;
            this.LblTituloLibro.Text = "Título del Libro:";
            // 
            // BtnSeleccionLibro
            // 
            this.BtnSeleccionLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnSeleccionLibro.FlatAppearance.BorderSize = 2;
            this.BtnSeleccionLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSeleccionLibro.Location = new System.Drawing.Point(525, 226);
            this.BtnSeleccionLibro.Name = "BtnSeleccionLibro";
            this.BtnSeleccionLibro.Size = new System.Drawing.Size(124, 37);
            this.BtnSeleccionLibro.TabIndex = 13;
            this.BtnSeleccionLibro.Text = "Ordenar (Selección)";
            this.BtnSeleccionLibro.UseVisualStyleBackColor = true;
            this.BtnSeleccionLibro.Click += new System.EventHandler(this.BtnSeleccionLibro_Click);
            // 
            // BtnBurbujaLibro
            // 
            this.BtnBurbujaLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnBurbujaLibro.FlatAppearance.BorderSize = 2;
            this.BtnBurbujaLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBurbujaLibro.Location = new System.Drawing.Point(370, 226);
            this.BtnBurbujaLibro.Name = "BtnBurbujaLibro";
            this.BtnBurbujaLibro.Size = new System.Drawing.Size(124, 37);
            this.BtnBurbujaLibro.TabIndex = 12;
            this.BtnBurbujaLibro.Text = "Ordenar (Burbuja)";
            this.BtnBurbujaLibro.UseVisualStyleBackColor = true;
            this.BtnBurbujaLibro.Click += new System.EventHandler(this.BtnBurbujaLibro_Click);
            // 
            // BtnEliminarLibro
            // 
            this.BtnEliminarLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnEliminarLibro.FlatAppearance.BorderSize = 2;
            this.BtnEliminarLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEliminarLibro.Location = new System.Drawing.Point(525, 173);
            this.BtnEliminarLibro.Name = "BtnEliminarLibro";
            this.BtnEliminarLibro.Size = new System.Drawing.Size(124, 37);
            this.BtnEliminarLibro.TabIndex = 11;
            this.BtnEliminarLibro.Text = "Eliminar";
            this.BtnEliminarLibro.UseVisualStyleBackColor = true;
            this.BtnEliminarLibro.Click += new System.EventHandler(this.BtnEliminarLibro_Click);
            // 
            // BtnBuscarLibro
            // 
            this.BtnBuscarLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnBuscarLibro.FlatAppearance.BorderSize = 2;
            this.BtnBuscarLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBuscarLibro.Location = new System.Drawing.Point(370, 173);
            this.BtnBuscarLibro.Name = "BtnBuscarLibro";
            this.BtnBuscarLibro.Size = new System.Drawing.Size(124, 37);
            this.BtnBuscarLibro.TabIndex = 10;
            this.BtnBuscarLibro.Text = "Buscar";
            this.BtnBuscarLibro.UseVisualStyleBackColor = true;
            this.BtnBuscarLibro.Click += new System.EventHandler(this.BtnBuscarLibro_Click);
            // 
            // BtnMostrarLibro
            // 
            this.BtnMostrarLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnMostrarLibro.FlatAppearance.BorderSize = 2;
            this.BtnMostrarLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMostrarLibro.Location = new System.Drawing.Point(215, 173);
            this.BtnMostrarLibro.Name = "BtnMostrarLibro";
            this.BtnMostrarLibro.Size = new System.Drawing.Size(124, 37);
            this.BtnMostrarLibro.TabIndex = 9;
            this.BtnMostrarLibro.Text = "Mostrar";
            this.BtnMostrarLibro.UseVisualStyleBackColor = true;
            this.BtnMostrarLibro.Click += new System.EventHandler(this.BtnMostrarLibros_Click);
            // 
            // BtnRegistrarLibro
            // 
            this.BtnRegistrarLibro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnRegistrarLibro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRegistrarLibro.Location = new System.Drawing.Point(64, 173);
            this.BtnRegistrarLibro.Name = "BtnRegistrarLibro";
            this.BtnRegistrarLibro.Size = new System.Drawing.Size(124, 37);
            this.BtnRegistrarLibro.TabIndex = 8;
            this.BtnRegistrarLibro.Text = "Registrar";
            this.BtnRegistrarLibro.UseVisualStyleBackColor = true;
            this.BtnRegistrarLibro.Click += new System.EventHandler(this.BtnRegistrarLibro_Click);
            // 
            // TabPrestamos
            // 
            this.TabPrestamos.Controls.Add(this.panel12);
            this.TabPrestamos.Controls.Add(this.panel11);
            this.TabPrestamos.Controls.Add(this.BtnBuscarPrestamo);
            this.TabPrestamos.Controls.Add(this.BtnMostrarPrestamo);
            this.TabPrestamos.Controls.Add(this.BtnRegistrarPrestamo);
            this.TabPrestamos.Location = new System.Drawing.Point(4, 22);
            this.TabPrestamos.Name = "TabPrestamos";
            this.TabPrestamos.Size = new System.Drawing.Size(733, 518);
            this.TabPrestamos.TabIndex = 2;
            this.TabPrestamos.Text = "Préstamos";
            this.TabPrestamos.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel12.Controls.Add(this.GpbRegistrosPrestamo);
            this.panel12.Location = new System.Drawing.Point(22, 278);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(697, 221);
            this.panel12.TabIndex = 18;
            // 
            // GpbRegistrosPrestamo
            // 
            this.GpbRegistrosPrestamo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbRegistrosPrestamo.Controls.Add(this.DgvPrestamos);
            this.GpbRegistrosPrestamo.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbRegistrosPrestamo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbRegistrosPrestamo.Location = new System.Drawing.Point(13, 3);
            this.GpbRegistrosPrestamo.Name = "GpbRegistrosPrestamo";
            this.GpbRegistrosPrestamo.Size = new System.Drawing.Size(671, 214);
            this.GpbRegistrosPrestamo.TabIndex = 12;
            this.GpbRegistrosPrestamo.TabStop = false;
            this.GpbRegistrosPrestamo.Text = "Registros de Préstamos";
            // 
            // DgvPrestamos
            // 
            this.DgvPrestamos.AllowUserToAddRows = false;
            this.DgvPrestamos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DgvPrestamos.BackgroundColor = System.Drawing.Color.White;
            this.DgvPrestamos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DgvPrestamos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(212)))), ((int)(((byte)(92)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DgvPrestamos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.DgvPrestamos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DgvPrestamos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.ColCodULLibroP,
            this.ColFechaPrestamo,
            this.ColFechaDevolucion,
            this.ColEstado});
            this.DgvPrestamos.EnableHeadersVisualStyles = false;
            this.DgvPrestamos.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(228)))), ((int)(((byte)(232)))));
            this.DgvPrestamos.Location = new System.Drawing.Point(14, 28);
            this.DgvPrestamos.Name = "DgvPrestamos";
            this.DgvPrestamos.RowHeadersVisible = false;
            this.DgvPrestamos.Size = new System.Drawing.Size(639, 167);
            this.DgvPrestamos.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Código del Estudiante";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // ColCodULLibroP
            // 
            this.ColCodULLibroP.HeaderText = "Código UL del Libro";
            this.ColCodULLibroP.Name = "ColCodULLibroP";
            // 
            // ColFechaPrestamo
            // 
            this.ColFechaPrestamo.HeaderText = "Fecha de Préstamo";
            this.ColFechaPrestamo.Name = "ColFechaPrestamo";
            // 
            // ColFechaDevolucion
            // 
            this.ColFechaDevolucion.HeaderText = "Fecha de Devolución";
            this.ColFechaDevolucion.Name = "ColFechaDevolucion";
            // 
            // ColEstado
            // 
            this.ColEstado.HeaderText = "Estado";
            this.ColEstado.Name = "ColEstado";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel11.Controls.Add(this.GpbGestionPrestamo);
            this.panel11.Location = new System.Drawing.Point(16, 28);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(707, 127);
            this.panel11.TabIndex = 18;
            // 
            // BtnBuscarPrestamo
            // 
            this.BtnBuscarPrestamo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnBuscarPrestamo.FlatAppearance.BorderSize = 2;
            this.BtnBuscarPrestamo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBuscarPrestamo.Location = new System.Drawing.Point(444, 198);
            this.BtnBuscarPrestamo.Name = "BtnBuscarPrestamo";
            this.BtnBuscarPrestamo.Size = new System.Drawing.Size(120, 34);
            this.BtnBuscarPrestamo.TabIndex = 11;
            this.BtnBuscarPrestamo.Text = "Buscar";
            this.BtnBuscarPrestamo.UseVisualStyleBackColor = true;
            this.BtnBuscarPrestamo.Click += new System.EventHandler(this.BtnBuscarPrestamo_Click);
            // 
            // BtnMostrarPrestamo
            // 
            this.BtnMostrarPrestamo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnMostrarPrestamo.FlatAppearance.BorderSize = 2;
            this.BtnMostrarPrestamo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMostrarPrestamo.Location = new System.Drawing.Point(287, 198);
            this.BtnMostrarPrestamo.Name = "BtnMostrarPrestamo";
            this.BtnMostrarPrestamo.Size = new System.Drawing.Size(120, 34);
            this.BtnMostrarPrestamo.TabIndex = 10;
            this.BtnMostrarPrestamo.Text = "Mostrar";
            this.BtnMostrarPrestamo.UseVisualStyleBackColor = true;
            this.BtnMostrarPrestamo.Click += new System.EventHandler(this.BtnMostrarPrestamo_Click);
            // 
            // BtnRegistrarPrestamo
            // 
            this.BtnRegistrarPrestamo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnRegistrarPrestamo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRegistrarPrestamo.Location = new System.Drawing.Point(137, 198);
            this.BtnRegistrarPrestamo.Name = "BtnRegistrarPrestamo";
            this.BtnRegistrarPrestamo.Size = new System.Drawing.Size(120, 34);
            this.BtnRegistrarPrestamo.TabIndex = 9;
            this.BtnRegistrarPrestamo.Text = "Registrar";
            this.BtnRegistrarPrestamo.UseVisualStyleBackColor = true;
            this.BtnRegistrarPrestamo.Click += new System.EventHandler(this.BtnRegistrarPrestamo_Click);
            // 
            // TabDevoluciones
            // 
            this.TabDevoluciones.Controls.Add(this.panel14);
            this.TabDevoluciones.Controls.Add(this.panel17);
            this.TabDevoluciones.Controls.Add(this.panel13);
            this.TabDevoluciones.Controls.Add(this.BtnRegistrarDevolucion);
            this.TabDevoluciones.Controls.Add(this.BtnHistorialDevoluciones);
            this.TabDevoluciones.Location = new System.Drawing.Point(4, 22);
            this.TabDevoluciones.Name = "TabDevoluciones";
            this.TabDevoluciones.Size = new System.Drawing.Size(733, 518);
            this.TabDevoluciones.TabIndex = 3;
            this.TabDevoluciones.Text = "Devoluciones";
            this.TabDevoluciones.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel14.Controls.Add(this.GpbRegistroDevoluciones);
            this.panel14.Location = new System.Drawing.Point(22, 223);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(691, 268);
            this.panel14.TabIndex = 18;
            // 
            // GpbRegistroDevoluciones
            // 
            this.GpbRegistroDevoluciones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(208)))));
            this.GpbRegistroDevoluciones.Controls.Add(this.TxtDevolucion);
            this.GpbRegistroDevoluciones.Font = new System.Drawing.Font("Sylfaen", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GpbRegistroDevoluciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(38)))), ((int)(((byte)(43)))));
            this.GpbRegistroDevoluciones.Location = new System.Drawing.Point(18, 3);
            this.GpbRegistroDevoluciones.Name = "GpbRegistroDevoluciones";
            this.GpbRegistroDevoluciones.Size = new System.Drawing.Size(650, 262);
            this.GpbRegistroDevoluciones.TabIndex = 12;
            this.GpbRegistroDevoluciones.TabStop = false;
            this.GpbRegistroDevoluciones.Text = "Registro de Devoluciones";
            // 
            // TxtDevolucion
            // 
            this.TxtDevolucion.Location = new System.Drawing.Point(24, 38);
            this.TxtDevolucion.Multiline = true;
            this.TxtDevolucion.Name = "TxtDevolucion";
            this.TxtDevolucion.ReadOnly = true;
            this.TxtDevolucion.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TxtDevolucion.Size = new System.Drawing.Size(613, 208);
            this.TxtDevolucion.TabIndex = 5;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel17.Location = new System.Drawing.Point(49, 71);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(5, 15);
            this.panel17.TabIndex = 20;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.panel13.Controls.Add(this.GpbDevoluciones);
            this.panel13.Location = new System.Drawing.Point(22, 22);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(691, 90);
            this.panel13.TabIndex = 18;
            // 
            // BtnRegistrarDevolucion
            // 
            this.BtnRegistrarDevolucion.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnRegistrarDevolucion.FlatAppearance.BorderSize = 2;
            this.BtnRegistrarDevolucion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRegistrarDevolucion.Location = new System.Drawing.Point(160, 147);
            this.BtnRegistrarDevolucion.Name = "BtnRegistrarDevolucion";
            this.BtnRegistrarDevolucion.Size = new System.Drawing.Size(162, 37);
            this.BtnRegistrarDevolucion.TabIndex = 11;
            this.BtnRegistrarDevolucion.Text = "Registrar";
            this.BtnRegistrarDevolucion.UseVisualStyleBackColor = true;
            this.BtnRegistrarDevolucion.Click += new System.EventHandler(this.BtnRegistrarDevolucion_Click);
            // 
            // BtnHistorialDevoluciones
            // 
            this.BtnHistorialDevoluciones.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(210)))), ((int)(((byte)(63)))));
            this.BtnHistorialDevoluciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnHistorialDevoluciones.Location = new System.Drawing.Point(407, 147);
            this.BtnHistorialDevoluciones.Name = "BtnHistorialDevoluciones";
            this.BtnHistorialDevoluciones.Size = new System.Drawing.Size(162, 37);
            this.BtnHistorialDevoluciones.TabIndex = 10;
            this.BtnHistorialDevoluciones.Text = "Historial de Devoluciones";
            this.BtnHistorialDevoluciones.UseVisualStyleBackColor = true;
            this.BtnHistorialDevoluciones.Click += new System.EventHandler(this.BtnHistorialDevoluciones_Click);
            // 
            // BtnLibros
            // 
            this.BtnLibros.FlatAppearance.BorderSize = 0;
            this.BtnLibros.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(25)))));
            this.BtnLibros.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLibros.ForeColor = System.Drawing.Color.White;
            this.BtnLibros.Location = new System.Drawing.Point(0, 59);
            this.BtnLibros.Name = "BtnLibros";
            this.BtnLibros.Size = new System.Drawing.Size(139, 57);
            this.BtnLibros.TabIndex = 13;
            this.BtnLibros.Text = "Libros";
            this.BtnLibros.UseVisualStyleBackColor = false;
            this.BtnLibros.Click += new System.EventHandler(this.BtnLibros_Click);
            // 
            // BtnPrestamo
            // 
            this.BtnPrestamo.FlatAppearance.BorderSize = 0;
            this.BtnPrestamo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(25)))));
            this.BtnPrestamo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPrestamo.ForeColor = System.Drawing.Color.White;
            this.BtnPrestamo.Location = new System.Drawing.Point(0, 115);
            this.BtnPrestamo.Name = "BtnPrestamo";
            this.BtnPrestamo.Size = new System.Drawing.Size(139, 57);
            this.BtnPrestamo.TabIndex = 14;
            this.BtnPrestamo.Text = "Préstamos";
            this.BtnPrestamo.UseVisualStyleBackColor = false;
            this.BtnPrestamo.Click += new System.EventHandler(this.BtnPrestamo_Click);
            // 
            // BtnDevoluciones
            // 
            this.BtnDevoluciones.FlatAppearance.BorderSize = 0;
            this.BtnDevoluciones.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(25)))));
            this.BtnDevoluciones.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDevoluciones.ForeColor = System.Drawing.Color.White;
            this.BtnDevoluciones.Location = new System.Drawing.Point(0, 171);
            this.BtnDevoluciones.Name = "BtnDevoluciones";
            this.BtnDevoluciones.Size = new System.Drawing.Size(139, 57);
            this.BtnDevoluciones.TabIndex = 15;
            this.BtnDevoluciones.Text = "Devoluciones";
            this.BtnDevoluciones.UseVisualStyleBackColor = false;
            this.BtnDevoluciones.Click += new System.EventHandler(this.BtnDevoluciones_Click);
            // 
            // PnlBotones
            // 
            this.PnlBotones.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PnlBotones.Controls.Add(this.BtnDevoluciones);
            this.PnlBotones.Controls.Add(this.BtnEstudiantes);
            this.PnlBotones.Controls.Add(this.BtnPrestamo);
            this.PnlBotones.Controls.Add(this.BtnLibros);
            this.PnlBotones.Location = new System.Drawing.Point(-1, 102);
            this.PnlBotones.Name = "PnlBotones";
            this.PnlBotones.Size = new System.Drawing.Size(139, 437);
            this.PnlBotones.TabIndex = 16;
            // 
            // BtnEstudiantes
            // 
            this.BtnEstudiantes.FlatAppearance.BorderSize = 0;
            this.BtnEstudiantes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(25)))));
            this.BtnEstudiantes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEstudiantes.ForeColor = System.Drawing.Color.White;
            this.BtnEstudiantes.Location = new System.Drawing.Point(0, 3);
            this.BtnEstudiantes.Name = "BtnEstudiantes";
            this.BtnEstudiantes.Size = new System.Drawing.Size(139, 57);
            this.BtnEstudiantes.TabIndex = 12;
            this.BtnEstudiantes.Text = "Estudiantes";
            this.BtnEstudiantes.UseVisualStyleBackColor = false;
            this.BtnEstudiantes.Click += new System.EventHandler(this.BtnEstudiantes_Click);
            // 
            // PnlLogo
            // 
            this.PnlLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(25)))));
            this.PnlLogo.Controls.Add(this.PicLogo);
            this.PnlLogo.Location = new System.Drawing.Point(0, 0);
            this.PnlLogo.Name = "PnlLogo";
            this.PnlLogo.Size = new System.Drawing.Size(138, 102);
            this.PnlLogo.TabIndex = 17;
            // 
            // PicLogo
            // 
            this.PicLogo.Image = ((System.Drawing.Image)(resources.GetObject("PicLogo.Image")));
            this.PicLogo.Location = new System.Drawing.Point(19, 22);
            this.PicLogo.Name = "PicLogo";
            this.PicLogo.Size = new System.Drawing.Size(100, 60);
            this.PicLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicLogo.TabIndex = 6;
            this.PicLogo.TabStop = false;
            this.PicLogo.Click += new System.EventHandler(this.PicLogo_Click);
            // 
            // FrmBiblioteca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(869, 546);
            this.Controls.Add(this.PnlLogo);
            this.Controls.Add(this.PnlBotones);
            this.Controls.Add(this.TabContenido);
            this.Name = "FrmBiblioteca";
            this.Text = "Biblioteca UPN";
            this.GpbEstudiantes.ResumeLayout(false);
            this.GpbEstudiantes.PerformLayout();
            this.GpbGestionPrestamo.ResumeLayout(false);
            this.GpbGestionPrestamo.PerformLayout();
            this.GpbDevoluciones.ResumeLayout(false);
            this.GpbDevoluciones.PerformLayout();
            this.TabContenido.ResumeLayout(false);
            this.TabBienvenida.ResumeLayout(false);
            this.TabBienvenida.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.TabEstudiantes.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.GpbRegistroEstudiantes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvEstudiantes)).EndInit();
            this.panel1.ResumeLayout(false);
            this.TabLibros.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.GpbRegistrosLibro.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvLibros)).EndInit();
            this.panel7.ResumeLayout(false);
            this.GpbDatosLibro.ResumeLayout(false);
            this.GpbDatosLibro.PerformLayout();
            this.TabPrestamos.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.GpbRegistrosPrestamo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DgvPrestamos)).EndInit();
            this.panel11.ResumeLayout(false);
            this.TabDevoluciones.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.GpbRegistroDevoluciones.ResumeLayout(false);
            this.GpbRegistroDevoluciones.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.PnlBotones.ResumeLayout(false);
            this.PnlLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PicLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label LblCodigoEstudiante;
        private System.Windows.Forms.GroupBox GpbEstudiantes;
        private System.Windows.Forms.Label LblNombreEstudiante;
        private System.Windows.Forms.Label LblApellidosEstudiante;
        private System.Windows.Forms.ComboBox CmbEstadoMatricula;
        private System.Windows.Forms.Label LblEstadoMatricula;
        private System.Windows.Forms.TextBox TxtApellidosEstudiante;
        private System.Windows.Forms.TextBox TxtNombresEstudiante;
        private System.Windows.Forms.TextBox TxtCodigoEstudiante;
        private System.Windows.Forms.GroupBox GpbGestionPrestamo;
        private System.Windows.Forms.TextBox TxtCodigoULPrestamo;
        private System.Windows.Forms.Label LblCodigoEstPrestamo;
        private System.Windows.Forms.TextBox TxtCodigoEstPrestamo;
        private System.Windows.Forms.Label LblCodigoULPrestamo;
        private System.Windows.Forms.GroupBox GpbDevoluciones;
        private System.Windows.Forms.TextBox TxtCodigoULDevolucion;
        private System.Windows.Forms.Label LblCodigoULDevolucion;
        private System.Windows.Forms.TabControl TabContenido;
        private System.Windows.Forms.TabPage TabEstudiantes;
        private System.Windows.Forms.TabPage TabLibros;
        private System.Windows.Forms.TabPage TabPrestamos;
        private System.Windows.Forms.TabPage TabDevoluciones;
        private System.Windows.Forms.Button BtnLibros;
        private System.Windows.Forms.Button BtnPrestamo;
        private System.Windows.Forms.Button BtnDevoluciones;
        private System.Windows.Forms.Panel PnlBotones;
        private System.Windows.Forms.GroupBox GpbDatosLibro;
        private System.Windows.Forms.TextBox TxtAreaLibro;
        private System.Windows.Forms.TextBox TxtTituloLibro;
        private System.Windows.Forms.Label LblAreaLibro;
        private System.Windows.Forms.Label LblTituloLibro;
        private System.Windows.Forms.GroupBox GpbRegistroEstudiantes;
        private System.Windows.Forms.Panel PnlLogo;
        private System.Windows.Forms.PictureBox PicLogo;
        private System.Windows.Forms.TabPage TabBienvenida;
        private System.Windows.Forms.Button BtnEstudiantes;
        private System.Windows.Forms.Button BtnEliminar;
        private System.Windows.Forms.Button BtnBuscar;
        private System.Windows.Forms.Button BtnMostrarEstudiante;
        private System.Windows.Forms.Button BtnRegistrarEstudiante;
        private System.Windows.Forms.Button BtnBurbujaEstudiante;
        private System.Windows.Forms.Button BtnSeleccionEstudiante;
        private System.Windows.Forms.Button BtnSeleccionLibro;
        private System.Windows.Forms.Button BtnBurbujaLibro;
        private System.Windows.Forms.Button BtnEliminarLibro;
        private System.Windows.Forms.Button BtnBuscarLibro;
        private System.Windows.Forms.Button BtnMostrarLibro;
        private System.Windows.Forms.Button BtnRegistrarLibro;
        private System.Windows.Forms.GroupBox GpbRegistrosLibro;
        private System.Windows.Forms.Button BtnBuscarPrestamo;
        private System.Windows.Forms.Button BtnMostrarPrestamo;
        private System.Windows.Forms.Button BtnRegistrarPrestamo;
        private System.Windows.Forms.GroupBox GpbRegistrosPrestamo;
        private System.Windows.Forms.Button BtnRegistrarDevolucion;
        private System.Windows.Forms.Button BtnHistorialDevoluciones;
        private System.Windows.Forms.GroupBox GpbRegistroDevoluciones;
        private System.Windows.Forms.DataGridView DgvEstudiantes;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCodigoEst;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColNombresEst;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColApellidosEst;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColEstadoMatriculaEst;
        private System.Windows.Forms.DataGridView DgvLibros;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCodigoLibro;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColTituloLibro;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColAreaLibro;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCodULLibro;
        private System.Windows.Forms.DataGridView DgvPrestamos;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColCodULLibroP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColFechaPrestamo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColFechaDevolucion;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColEstado;
        private System.Windows.Forms.TextBox TxtDevolucion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label LblBienvenidos;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label LblTituloSistema_1;
        private System.Windows.Forms.Label LblTituloSistema_2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnModificarEstudiante;
        private System.Windows.Forms.Button btnModificarLibro;
        private System.Windows.Forms.Button btnCargarTxTEstudiantes;
        private System.Windows.Forms.Button btnCargarTxTLibros;
    }
}

